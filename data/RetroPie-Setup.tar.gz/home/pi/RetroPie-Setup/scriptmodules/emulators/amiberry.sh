#!/usr/bin/env bash

# This file is part of The RetroPie Project
#
# The RetroPie Project is the legal property of its developers, whose names are
# too numerous to list here. Please refer to the COPYRIGHT.md file distributed with this source.
#
# See the LICENSE.md file at the top-level directory of this distribution and
# at https://raw.githubusercontent.com/RetroPie/RetroPie-Setup/master/LICENSE.md
#

rp_module_id="amiberry"
rp_module_desc="Amiga emulator with JIT support (forked from uae4arm)"
rp_module_help="ROM Extension: .adf .ipf .zip\n\nCopy your Amiga games to $romdir/amiga\n\nCopy the required BIOS files\nkick13.rom\nkick20.rom\nkick31.rom\nto $biosdir"
rp_module_licence="GPL3 https://raw.githubusercontent.com/midwan/amiberry/master/COPYING"
rp_module_section="opt"
rp_module_flags="!all arm"

function _get_platform_amiberry() {
    local platform="$__platform-sdl2"
    if isPlatform "dispmanx"; then
        platform="$__platform"
    elif isPlatform "odroid-xu"; then
        platform="xu4"
    elif isPlatform "odroid-c1"; then
        platform="c1"
    elif isPlatform "tinker"; then
        platform="tinker"
    elif isPlatform "vero4k"; then
        platform="vero4k"
    elif isPlatform "H3-mali"; then
        platform="orangepi-pc"
    fi
    echo "$platform"
}

function depends_amiberry() {
    local depends=(autoconf libmpeg2-4-dev zlib1g-dev libmpg123-dev libflac-dev libxml2-dev libsdl2-dev libsdl2-image-dev libsdl2-ttf-dev)
    isPlatform "dispmanx" && depends+=(libraspberrypi-dev)
    isPlatform "vero4k" && depends+=(vero3-userland-dev-osmc)

    getDepends "${depends[@]}"
}

function sources_amiberry() {
    gitPullOrClone "$md_build" https://github.com/midwan/amiberry
    cp /home/pi/RetroPie-Setup/scriptmodules/emulators/amiberry/amiberry /home/pi/RetroPie-Setup/tmp/build/amiberry
    # use our default optimisation level
    sed -i "s/-Ofast//" "$md_build/Makefile"
}

function build_amiberry() {
    local platform=$(_get_platform_amiberry)
    cd external/capsimg
#    ./bootstrap.fs
#    ./configure.fs
#    make -f Makefile.fs clean
#    make -f Makefile.fs
#    cd "$md_build"
#    make clean
#    make PLATFORM="$platform"
    md_ret_require="$md_build/amiberry"
}

function install_amiberry() {
    md_ret_files=(
        'amiberry'
        'data'
    #    'external/capsimg/capsimg.so'
    )

    cp -R "$md_build/whdboot" "$md_inst/whdboot-dist"

}

function configure_amiberry() {

    mkRomDir "amiga"
    # moving previous emulator configs
    mv "$md_conf_root/amiga/emulators.cfg" /home/pi/temp
    mkUserDir "$md_conf_root/amiga"
    mkUserDir "$md_conf_root/amiga/$md_id"

    # move config / save folders to $md_conf_root/amiga/$md_id
    local dir
    for dir in conf savestates screenshots; do
        moveConfigDir "$md_inst/$dir" "$md_conf_root/amiga/$md_id/$dir"
    done

    # and kickstart dir (removing old symlinks first)
    if [[ ! -h "$md_inst/kickstarts" ]]; then
        rm -f "$md_inst/kickstarts/"{kick12.rom,kick13.rom,kick20.rom,kick31.rom}
    fi
    moveConfigDir "$md_inst/kickstarts" "$biosdir"

    local conf="$(mktemp)"
    iniConfig "=" "" "$conf"
    iniSet "config_description" "RetroPie A500, 68000, OCS, 512KB Chip + 512KB Slow Fast"
    iniSet "chipmem_size" "1"
    iniSet "bogomem_size" "2"
    iniSet "chipset" "ocs"
    iniSet "cachesize" "0"
    iniSet "kickstart_rom_file" "\$(FILE_PATH)/kick13.rom"
    copyDefaultConfig "$conf" "$md_conf_root/amiga/$md_id/conf/rp-a500.uae"
    rm "$conf"

    conf="$(mktemp)"
    iniConfig "=" "" "$conf"
    iniSet "config_description" "RetroPie A1200, 68EC020, AGA, 2MB Chip"
    iniSet "chipmem_size" "4"
    iniSet "finegrain_cpu_speed" "1024"
    iniSet "cpu_type" "68ec020"
    iniSet "cpu_model" "68020"
    iniSet "chipset" "aga"
    iniSet "cachesize" "0"
    iniSet "kickstart_rom_file" "\$(FILE_PATH)/kick31.rom"
    copyDefaultConfig "$conf" "$md_conf_root/amiga/$md_id/conf/rp-a1200.uae"
    rm "$conf"

    # copy launch script (used for uae4arm and amiberry)
    sed "s/EMULATOR/$md_id/" "$scriptdir/scriptmodules/$md_type/uae4arm/uae4arm.sh" >"$md_inst/$md_id.sh"
    chmod a+x "$md_inst/$md_id.sh"

    local script="+Start UAE4Arm.sh"
    [[ "$md_id" == "amiberry" ]] && script="+Start Amiberry.sh"
    rm -f "$romdir/amiga/$script"
    if [[ "$md_mode" == "install" ]]; then
        cat > "$romdir/amiga/$script" << _EOF_
#!/bin/bash
$md_inst/$md_id.sh
_EOF_
        chmod a+x "$romdir/amiga/$script"
        chown $user:$user "$romdir/amiga/$script"
    fi

    # symlink the retroarch config / autoconfigs for amiberry to use
    ln -sf "$configdir/all/retroarch/autoconfig" "$md_inst/controllers"
    ln -sf "$configdir/all/retroarch.cfg" "$md_inst/conf/retroarch.cfg"

    local config_dir="$md_conf_root/amiga/$md_id"

    # create whdboot config area
    moveConfigDir "$md_inst/whdboot" "$config_dir/whdboot"

    # move hostprefs.conf from previous location
    if [[ -f "$config_dir/conf/hostprefs.conf" ]]; then
        mv "$config_dir/conf/hostprefs.conf" "$config_dir/whdboot/hostprefs.conf"
    fi

    # whdload auto-booter user config - copy default configuration
    copyDefaultConfig "$md_inst/whdboot-dist/hostprefs.conf" "$config_dir/whdboot/hostprefs.conf"

    # copy game-data, save-data folders, boot-data.zip and WHDLoad
    cp -R "$md_inst/whdboot-dist/"{game-data,save-data,boot-data.zip,WHDLoad} "$config_dir/whdboot/"

    chown -R $user:$user "$config_dir/whdboot"

    addEmulator 1 "$md_id" "amiga" "$md_inst/$md_id.sh auto %ROM%"
    addEmulator 1 "$md_id-a500" "amiga" "$md_inst/$md_id.sh rp-a500.uae %ROM%"
    addEmulator 1 "$md_id-a1200" "amiga" "$md_inst/$md_id.sh rp-a1200.uae %ROM%"
    addSystem "amiga"

}
